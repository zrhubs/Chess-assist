# Chess Assist (Android)

Floating overlay that reads the board in any chess app on screen, runs Stockfish on-device,
and draws the best-move arrow over it. Arrow color, strength (Elo) and think time are adjustable.

## Build
1. Install Android Studio and open this folder. Let it sync and generate the Gradle wrapper.
2. Get Stockfish for Android (ARMv8) from https://stockfishchess.org/download/
   - Extract the binary, rename it to `libstockfish.so`
   - Put it in `app/src/main/jniLibs/arm64-v8a/libstockfish.so`
3. Build > Build APK(s). Install the APK on the phone (allow "install unknown apps").

## Use
1. Open Chess Assist and set arrow color, strength and think time.
2. Tap **1. Allow overlay** and enable it.
3. Tap **2. Start** and choose **Entire screen** (not a single app).
4. Open your chess app and start a game. The board must be at the starting position.
5. On the floating bar, tap **Board**. Drag the green square over the board and resize it with the bottom-right dot so the grid lines match the squares. Tap **Lock**.
6. Play. On your turn the arrow appears. It hides when you touch the screen and comes back if you don't move.
   - **On/Off** pauses it. **Exit** stops everything.
   - Keep the bar off the board, or it will block recognition.
   - Changing piece set, board theme, or rotation means you need to tap **Board** and lock again on a new game.

## Limits
- Portrait only. Recognition is calibrated from the starting position's look.
- Castling rights are inferred from pieces on home squares. En passant isn't detected.
- Whose turn it is comes from which color's piece moved last. A misread can flip it. Starting a new game resets it.
