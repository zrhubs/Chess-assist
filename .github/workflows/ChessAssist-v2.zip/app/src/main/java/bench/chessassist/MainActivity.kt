package bench.chessassist

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.*

class MainActivity : Activity() {
    private val reqCapture = 42
    private lateinit var status: TextView
    private var dp = 1f

    private val ACCENT = 0xFF00C878.toInt()
    private val BG = 0xFF0E0F13.toInt()
    private val CARD = 0xFF1A1C23.toInt()
    private val MUTED = 0xFF8A8F9C.toInt()

    private fun px(v: Int) = (v * dp).toInt()
    private fun round(color: Int, r: Int = 18) =
        GradientDrawable().apply { setColor(color); cornerRadius = px(r).toFloat() }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(CARD)
        setPadding(px(16), px(14), px(16), px(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(14) }
    }

    private fun heading(t: String) = TextView(this).apply {
        text = t.uppercase(); textSize = 12f; setTextColor(MUTED)
        typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.1f
    }

    private fun body(t: String, size: Float = 16f) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); setPadding(0, px(6), 0, px(2))
    }

    private fun pill(t: String, fill: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t; gravity = Gravity.CENTER; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (fill == ACCENT) Color.BLACK else Color.WHITE)
        background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), round(fill, 26), null)
        setPadding(0, px(14), 0, px(14)); isClickable = true
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(10) }
    }

    private fun slider(max: Int, value: Int, cb: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = value
        progressTintList = ColorStateList.valueOf(ACCENT)
        thumbTintList = ColorStateList.valueOf(ACCENT)
        setPadding(px(4), px(10), px(4), px(6))
        setOnSeekBarChangeListener(onChange(cb))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dp = resources.displayMetrics.density
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(18), px(18), px(18), px(28))
        }

        // ---- bouncing header ----
        val header = FrameLayout(this).apply {
            background = round(CARD, 22)
            layoutParams = LinearLayout.LayoutParams(-1, px(150))
        }
        header.addView(Bouncer(this, "evil rad"), FrameLayout.LayoutParams(-1, -1))
        root.addView(header)

        status = body("", 13f).apply { setTextColor(MUTED); gravity = Gravity.CENTER; setPadding(0, px(10), 0, 0) }
        root.addView(status)

        // ---- arrow color ----
        val colorCard = card()
        colorCard.addView(heading("Arrow color"))
        val preview = View(this).apply {
            background = round(Prefs.arrowColor(this@MainActivity), 6)
            layoutParams = LinearLayout.LayoutParams(-1, px(8)).apply { topMargin = px(12) }
        }
        val hex = EditText(this).apply {
            hint = "#AARRGGBB"; isSingleLine = true; setTextColor(Color.WHITE); setHintTextColor(MUTED)
            backgroundTintList = ColorStateList.valueOf(MUTED)
            setText(String.format("#%08X", Prefs.arrowColor(this@MainActivity)))
        }
        fun setColor(c: Int) {
            Prefs.setArrowColor(this, c)
            (preview.background as GradientDrawable).setColor(c)
            hex.setText(String.format("#%08X", c))
        }
        val presets = intArrayOf(
            0xD900C878.toInt(), 0xD92196F3.toInt(), 0xD9FF5252.toInt(),
            0xD9FFC107.toInt(), 0xD9E040FB.toInt(), 0xD9FFFFFF.toInt()
        )
        val swatches = LinearLayout(this).apply { setPadding(0, px(12), 0, 0) }
        presets.forEach { c ->
            swatches.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
                layoutParams = LinearLayout.LayoutParams(px(38), px(38)).apply { marginEnd = px(10) }
                setOnClickListener {
                    animate().scaleX(0.8f).scaleY(0.8f).setDuration(80).withEndAction {
                        animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }.start()
                    setColor(c)
                }
            })
        }
        colorCard.addView(swatches)
        val hexRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, px(8), 0, 0) }
        hexRow.addView(hex, LinearLayout.LayoutParams(0, -2, 1f))
        hexRow.addView(TextView(this).apply {
            text = "Apply"; setTextColor(ACCENT); typeface = Typeface.DEFAULT_BOLD
            setPadding(px(16), px(10), px(4), px(10))
            setOnClickListener {
                try { setColor(Color.parseColor(hex.text.toString().trim())) }
                catch (e: IllegalArgumentException) { toast("Bad color, use #AARRGGBB") }
            }
        })
        colorCard.addView(hexRow)
        colorCard.addView(preview)
        root.addView(colorCard)

        // ---- strength ----
        val strCard = card()
        strCard.addView(heading("How smart"))
        val eloLabel = body("")
        fun eloText(v: Int) {
            eloLabel.text = if (v >= Prefs.ELO_MAX) "Full strength" else "$v Elo"
        }
        eloText(Prefs.elo(this))
        strCard.addView(eloLabel)
        strCard.addView(slider(Prefs.ELO_MAX - Prefs.ELO_MIN, Prefs.elo(this) - Prefs.ELO_MIN) { p ->
            val e = p + Prefs.ELO_MIN; Prefs.setElo(this, e); eloText(e)
        })
        val msLabel = body("Think time: ${Prefs.moveTime(this)} ms", 14f).apply { setTextColor(MUTED) }
        strCard.addView(msLabel)
        strCard.addView(slider(Prefs.MS_MAX - Prefs.MS_MIN, Prefs.moveTime(this) - Prefs.MS_MIN) { p ->
            val v = p + Prefs.MS_MIN; Prefs.setMoveTime(this, v); msLabel.text = "Think time: $v ms"
        })
        root.addView(strCard)

        // ---- controls ----
        val ctl = card()
        ctl.addView(heading("Run"))
        ctl.addView(pill("1 · Allow overlay", 0xFF2A2D36.toInt()) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        ctl.addView(pill("2 · Start", ACCENT) { start() })
        ctl.addView(pill("Test engine", 0xFF2A2D36.toInt()) { testEngine() })
        ctl.addView(pill("Stop", 0xFF3A1E22.toInt()) {
            stopService(Intent(this, AssistService::class.java)); toast("Stopped")
        })
        root.addView(ctl)

        root.addView(body(
            "Start → Entire screen → new game in your chess app → Board → fit the grid → Lock. " +
            "Keep the floating bar off the board.", 13f).apply { setTextColor(MUTED); setPadding(px(4), px(16), px(4), 0) })

        root.addView(TextView(this).apply {
            text = "© evil rad"; textSize = 12f; setTextColor(0xFF555A66.toInt())
            gravity = Gravity.CENTER; setPadding(0, px(24), 0, 0)
        })

        val scroll = ScrollView(this).apply { setBackgroundColor(BG); isVerticalScrollBarEnabled = false; addView(root) }
        setContentView(scroll)

        // smooth entrance
        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            v.alpha = 0f; v.translationY = px(24).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(60L * i).setDuration(380)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) "overlay: allowed" else "overlay: not allowed yet"
    }

    private fun testEngine() {
        status.text = "testing engine…"
        val e = Engine(this)
        e.search("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", Prefs.elo(this), 500) { mv, ev ->
            runOnUiThread {
                status.text = if (mv != null) "engine OK → $mv $ev" else "engine FAILED: $ev"
            }
            e.close()
        }
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) { toast("Allow overlay first"); return }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Activity result API kept simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(req, res, data)
        if (req == reqCapture && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, AssistService::class.java).putExtra("code", res).putExtra("data", data)
            )
            moveTaskToBack(true)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

fun onChange(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = f(p)
    override fun onStartTrackingTouch(s: SeekBar?) {}
    override fun onStopTrackingTouch(s: SeekBar?) {}
}
