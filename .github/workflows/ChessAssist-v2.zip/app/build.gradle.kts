plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "bench.chessassist"
    compileSdk = 34

    defaultConfig {
        applicationId = "bench.chessassist"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // Fixed key so every new build installs over the previous one.
    signingConfigs {
        create("evil") {
            storeFile = file("release.keystore")
            storePassword = "evilrad123"
            keyAlias = "evilrad"
            keyPassword = "evilrad123"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("evil") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("evil") }
    }

    // Stockfish ships as libstockfish.so in jniLibs; it must be extracted to disk to be executable.
    packaging { jniLibs { useLegacyPackaging = true } }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
