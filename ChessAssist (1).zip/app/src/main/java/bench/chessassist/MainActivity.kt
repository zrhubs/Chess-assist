package bench.chessassist

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val reqCapture = 42
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun label(t: String, size: Float = 16f) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, px(14), 0, px(6))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(24), px(20), px(24))
        }
        root.addView(label("Chess Assist", 24f))
        status = label("", 13f); root.addView(status)

        // ---- arrow color ----
        root.addView(label("Arrow color"))
        val preview = View(this).apply { setBackgroundColor(Prefs.arrowColor(this@MainActivity)) }
        val hex = EditText(this).apply {
            hint = "#AARRGGBB"; isSingleLine = true
            setText(String.format("#%08X", Prefs.arrowColor(this@MainActivity)))
        }
        val presets = intArrayOf(
            0xD900C878.toInt(), 0xD92196F3.toInt(), 0xD9FF5252.toInt(),
            0xD9FFC107.toInt(), 0xD9E040FB.toInt(), 0xD9FFFFFF.toInt()
        )
        val swatches = LinearLayout(this)
        presets.forEach { c ->
            swatches.addView(View(this).apply {
                setBackgroundColor(c)
                layoutParams = LinearLayout.LayoutParams(px(40), px(40)).apply { marginEnd = px(8) }
                setOnClickListener {
                    Prefs.setArrowColor(context, c); preview.setBackgroundColor(c)
                    hex.setText(String.format("#%08X", c))
                }
            })
        }
        root.addView(swatches)
        val hexRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hexRow.addView(hex, LinearLayout.LayoutParams(0, -2, 1f))
        hexRow.addView(Button(this).apply {
            text = "Apply"
            setOnClickListener {
                try {
                    val c = Color.parseColor(hex.text.toString().trim())
                    Prefs.setArrowColor(context, c); preview.setBackgroundColor(c)
                } catch (e: IllegalArgumentException) { toast("Bad color, use #AARRGGBB") }
            }
        })
        root.addView(hexRow)
        root.addView(preview, LinearLayout.LayoutParams(-1, px(10)))

        // ---- strength ----
        val eloLabel = label("")
        fun eloText(v: Int) {
            eloLabel.text = if (v >= Prefs.ELO_MAX) "Strength: full (no limit)" else "Strength: $v Elo"
        }
        eloText(Prefs.elo(this))
        root.addView(eloLabel)
        root.addView(SeekBar(this).apply {
            max = Prefs.ELO_MAX - Prefs.ELO_MIN
            progress = Prefs.elo(context) - Prefs.ELO_MIN
            setOnSeekBarChangeListener(onChange { p ->
                val e = p + Prefs.ELO_MIN; Prefs.setElo(context, e); eloText(e)
            })
        })

        // ---- think time ----
        val msLabel = label("Think time: ${Prefs.moveTime(this)} ms")
        root.addView(msLabel)
        root.addView(SeekBar(this).apply {
            max = Prefs.MS_MAX - Prefs.MS_MIN
            progress = Prefs.moveTime(context) - Prefs.MS_MIN
            setOnSeekBarChangeListener(onChange { p ->
                val v = p + Prefs.MS_MIN; Prefs.setMoveTime(context, v); msLabel.text = "Think time: $v ms"
            })
        })

        // ---- controls ----
        root.addView(Button(this).apply {
            text = "1. Allow overlay"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply { text = "2. Start"; setOnClickListener { start() } })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener { stopService(Intent(context, AssistService::class.java)) }
        })
        root.addView(label(
            "Start → pick \"Entire screen\" → open your chess app on a fresh game (start position) → " +
            "tap Board → fit the square over the board (drag to move, bottom-right dot to resize) → tap Lock. " +
            "Keep the control bar off the board. Color/strength changes apply live.", 13f))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) "Overlay: allowed" else "Overlay: NOT allowed"
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) { toast("Allow overlay first"); return }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Activity result API kept simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(req, res, data)
        if (req == reqCapture && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, AssistService::class.java).putExtra("code", res).putExtra("data", data)
            )
            moveTaskToBack(true)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

fun onChange(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = f(p)
    override fun onStartTrackingTouch(s: SeekBar?) {}
    override fun onStopTrackingTouch(s: SeekBar?) {}
}
