package bench.chessassist

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Captures the screen, reads the board, runs Stockfish, draws the arrow over the chess app.
 * The arrow hides the moment you touch the screen so it never pollutes the next read.
 */
class AssistService : Service() {
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val bgThread = HandlerThread("capture").apply { start() }
    private val bg by lazy { Handler(bgThread.looper) }
    private val main = Handler(Looper.getMainLooper())
    private var frame: Bitmap? = null
    private var sw = 0; private var sh = 0

    private val views = ArrayList<View>()
    private lateinit var arrow: ArrowView
    private lateinit var bar: LinearLayout
    private lateinit var barLp: LP
    private lateinit var statusTv: TextView
    private lateinit var boardBtn: Button
    private var selector: FrameSelector? = null

    @Volatile private var boardReader: BoardReader? = null
    @Volatile private var enabled = true
    @Volatile private var arrowShown = false
    @Volatile private var hiddenAt = 0L
    @Volatile private var analyzedFen: String? = null
    @Volatile private var cachedMove: String? = null
    @Volatile private var cachedEval = ""

    private var candidate: String? = null
    private var candCount = 0
    private var stable: Array<CharArray>? = null
    private var stableKey: String? = null
    private var side = 'w'
    private var engine: Engine? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(WindowManager::class.java)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
        }
        setupCapture()
        setupOverlays()
        engine = Engine(this)
        bg.post(loop)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("assist", "Assist", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "assist")
            .setContentTitle("Chess Assist running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------------- capture ----------------
    private fun setupCapture() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds; sw = b.width(); sh = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            sw = dm.widthPixels; sh = dm.heightPixels
        }
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay(
            "assist", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, bg
        )
    }

    /** Latest screen frame; reuses the previous one when the screen hasn't changed. */
    private fun grab(): Bitmap? {
        val img = try { reader?.acquireLatestImage() } catch (e: IllegalStateException) { null } ?: return frame
        try {
            val pl = img.planes[0]
            val w = pl.rowStride / pl.pixelStride
            var b = frame
            if (b == null || b.width != w || b.height != img.height) {
                b = Bitmap.createBitmap(w, img.height, Bitmap.Config.ARGB_8888); frame = b
            }
            pl.buffer.rewind()
            b.copyPixelsFromBuffer(pl.buffer)
        } catch (_: RuntimeException) {
        } finally { img.close() }
        return frame
    }

    private val loop = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) {}
            bg.postDelayed(this, 200)
        }
    }

    private fun tick() {
        val bmp = grab()                                     // always drain the reader
        val br = boardReader ?: return
        if (!enabled || arrowShown || bmp == null) return
        if (System.currentTimeMillis() - hiddenAt < 250) return  // let the arrow-free frame land

        val g = br.read(bmp)
        if (!Fen.sane(g)) return
        val key = g.joinToString("/") { String(it) }
        if (key != candidate) { candidate = key; candCount = 1; return }
        if (++candCount < 2) return                          // 2 identical reads = settled

        if (key != stableKey) {
            val prev = stable
            when {
                key == BoardReader.START_KEY -> side = 'w'
                prev != null -> {
                    var mover: Char? = null
                    for (r in 0..7) for (f in 0..7) {
                        val c = g[r][f]
                        if (c != prev[r][f] && c != '.') mover = if (c.isUpperCase()) 'w' else 'b'
                    }
                    if (mover != null) side = if (mover == 'w') 'b' else 'w'
                }
            }
            stable = g; stableKey = key
        }

        val me = if (br.flipped) 'b' else 'w'
        if (side != me) { ui { status("opponent's turn") }; return }

        val fen = Fen.of(g, side)
        if (fen == analyzedFen) {
            // touched without moving: bring the arrow back
            if (cachedMove != null && System.currentTimeMillis() - hiddenAt > 1500) ui { showArrow() }
            return
        }
        analyzedFen = fen; cachedMove = null
        ui { status("thinking…") }
        engine?.search(fen, Prefs.elo(this), Prefs.moveTime(this)) { mv, ev ->
            main.post {
                if (analyzedFen != fen) return@post
                if (mv == null) { status(ev.ifEmpty { "no move" }); return@post }
                cachedMove = mv; cachedEval = ev
                if (enabled) showArrow()
            }
        }
    }

    // ---------------- overlays ----------------
    private val type = LP.TYPE_APPLICATION_OVERLAY

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    private fun setupOverlays() {
        // arrow layer: touches pass through (alpha <= 0.8 required on Android 12+)
        arrow = ArrowView(this).apply { visibility = View.GONE }
        add(arrow, LP(LP.MATCH_PARENT, LP.MATCH_PARENT, type,
            LP.FLAG_NOT_TOUCHABLE or LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; alpha = 0.8f })

        // 1px sentinel: gets ACTION_OUTSIDE on any touch -> hide arrow
        val sentinel = object : View(this) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) hideArrow()
                return false
            }
        }
        add(sentinel, LP(1, 1, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })

        // control bar
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC111111.toInt()); setPadding(10, 10, 10, 10)
        }
        val handle = TextView(this).apply { text = "  ≡ drag  "; setTextColor(Color.WHITE); textSize = 14f }
        statusTv = TextView(this).apply { setTextColor(0xFF7FFFBF.toInt()); textSize = 12f; text = "tap Board" }
        boardBtn = Button(this).apply { text = "Board"; setOnClickListener { onBoardBtn() } }
        val toggle = Button(this).apply {
            text = "On"
            setOnClickListener {
                enabled = !enabled; text = if (enabled) "On" else "Off"
                if (!enabled) hideArrow()
                analyzedFen = null
            }
        }
        val exit = Button(this).apply { text = "Exit"; setOnClickListener { stopSelf() } }
        listOf(handle, statusTv, boardBtn, toggle, exit).forEach { bar.addView(it) }

        barLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 16; y = sh / 10
        }
        var sx = 0; var sy = 0; var rx = 0f; var ry = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = barLp.x; sy = barLp.y; rx = e.rawX; ry = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    barLp.x = sx + (e.rawX - rx).toInt(); barLp.y = sy + (e.rawY - ry).toInt()
                    wm.updateViewLayout(bar, barLp)
                }
            }
            true
        }
        add(bar, barLp)
    }

    private fun add(v: View, lp: LP) { wm.addView(v, lp); views += v }
    private fun remove(v: View) { runCatching { wm.removeView(v) }; views -= v }

    private fun onBoardBtn() {
        val sel = selector
        if (sel == null) {
            hideArrow(); boardReader = null
            val s = FrameSelector(this)
            add(s, LP(LP.MATCH_PARENT, LP.MATCH_PARENT, type,
                LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })
            remove(bar); add(bar, barLp)                     // keep bar above the selector
            selector = s; boardBtn.text = "Lock"
            status("fit square, start pos")
        } else {
            val rect = sel.screenRect()
            remove(sel); selector = null; boardBtn.text = "Board"
            status("reading…")
            bg.postDelayed({
                val bmp = grab()
                val br = bmp?.let { BoardReader.calibrate(it, rect) }
                candidate = null; candCount = 0; stable = null; stableKey = null
                side = 'w'; analyzedFen = null; cachedMove = null
                boardReader = br
                ui { status(when { br == null -> "calibration failed"; br.flipped -> "you: black"; else -> "you: white" }) }
            }, 400)
        }
    }

    private fun showArrow() {
        val br = boardReader ?: return
        val mv = cachedMove ?: return
        arrow.board = br.rect; arrow.flipped = br.flipped
        arrow.move = mv; arrow.eval = cachedEval
        arrow.visibility = View.VISIBLE; arrow.invalidate()
        arrowShown = true
        status("$mv  $cachedEval")
    }

    private fun hideArrow() {
        if (!arrowShown) return
        arrow.visibility = View.GONE
        arrowShown = false
        hiddenAt = System.currentTimeMillis()
    }

    private fun status(s: String) { statusTv.text = s }
    private fun ui(f: () -> Unit) { main.post(f) }

    override fun onDestroy() {
        bg.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) views.toList().forEach { remove(it) }
        vd?.release(); reader?.close()
        projection?.stop(); projection = null
        engine?.close()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
