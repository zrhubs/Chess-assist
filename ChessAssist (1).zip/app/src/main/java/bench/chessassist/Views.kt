package bench.chessassist

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** Full-screen, non-touchable arrow layer. */
class ArrowView(ctx: Context) : View(ctx) {
    var board: Rect? = null
    var flipped = false
    var move: String? = null
    var eval = ""

    private val loc = IntArray(2)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    private fun center(sq: String, r: Rect, out: FloatArray) {
        val f = sq[0] - 'a'; val rk = sq[1] - '1'
        val col = if (flipped) 7 - f else f
        val row = if (flipped) rk else 7 - rk
        val s = r.width() / 8f
        out[0] = r.left + (col + 0.5f) * s - loc[0]
        out[1] = r.top + (row + 0.5f) * s - loc[1]
    }

    override fun onDraw(c: Canvas) {
        val r = board ?: return
        val m = move ?: return
        if (m.length < 4) return
        getLocationOnScreen(loc)
        val color = Prefs.arrowColor(context)
        line.color = color; head.color = color
        val s = r.width() / 8f
        line.strokeWidth = s * 0.18f

        val a = FloatArray(2); val b = FloatArray(2)
        center(m.substring(0, 2), r, a); center(m.substring(2, 4), r, b)
        val ang = atan2(b[1] - a[1], b[0] - a[0])
        val hl = s * 0.45f
        c.drawLine(a[0], a[1], b[0] - cos(ang) * hl * 0.6f, b[1] - sin(ang) * hl * 0.6f, line)
        val p = Path().apply {
            moveTo(b[0], b[1])
            lineTo(b[0] - cos(ang - 0.5f) * hl, b[1] - sin(ang - 0.5f) * hl)
            lineTo(b[0] - cos(ang + 0.5f) * hl, b[1] - sin(ang + 0.5f) * hl)
            close()
        }
        c.drawPath(p, head)

        txt.textSize = s * 0.35f
        c.drawText("$m  $eval", r.left - loc[0] + 4f, r.top - loc[1] - 12f, txt)
    }
}

/** Movable / resizable square used to mark the board once. */
class FrameSelector(ctx: Context) : View(ctx) {
    private val r = RectF()
    private var mode = 0              // 0 none, 1 move, 2 resize
    private var lx = 0f; private var ly = 0f
    private val loc = IntArray(2)
    private val handleR = 36f

    private val dim = Paint().apply { color = 0x66000000 }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 4f }
    private val grid = Paint().apply { color = 0x8800FF00.toInt(); strokeWidth = 1.5f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (r.isEmpty) {
            val s = w * 0.95f
            r.set((w - s) / 2, (h - s) / 2, (w + s) / 2, (h + s) / 2)
        }
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), r.top, dim)
        c.drawRect(0f, r.bottom, width.toFloat(), height.toFloat(), dim)
        c.drawRect(0f, r.top, r.left, r.bottom, dim)
        c.drawRect(r.right, r.top, width.toFloat(), r.bottom, dim)
        val s = r.width() / 8
        for (i in 1..7) {
            c.drawLine(r.left + i * s, r.top, r.left + i * s, r.bottom, grid)
            c.drawLine(r.left, r.top + i * s, r.right, r.top + i * s, grid)
        }
        c.drawRect(r, edge)
        c.drawCircle(r.right, r.bottom, handleR, dot)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = when {
                    hypot(e.x - r.right, e.y - r.bottom) < handleR * 2 -> 2
                    r.contains(e.x, e.y) -> 1
                    else -> 0
                }
                lx = e.x; ly = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lx; val dy = e.y - ly
                if (mode == 1) r.offset(dx, dy)
                if (mode == 2) {
                    val size = max(80f, max(e.x - r.left, e.y - r.top))
                    r.right = r.left + size; r.bottom = r.top + size
                }
                lx = e.x; ly = e.y; invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }

    fun screenRect(): Rect {
        getLocationOnScreen(loc)
        return Rect(
            (r.left + loc[0]).roundToInt(), (r.top + loc[1]).roundToInt(),
            (r.right + loc[0]).roundToInt(), (r.bottom + loc[1]).roundToInt()
        )
    }
}
