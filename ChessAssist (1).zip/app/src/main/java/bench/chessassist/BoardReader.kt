package bench.chessassist

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.sqrt

/**
 * Screen-based board recognition.
 * Calibrated once on the starting position: every piece's look is sampled from the live
 * screen, so it adapts to whatever board theme / piece set the app uses.
 * Grid convention: grid[rank][file], rank 0 = rank 1, '.' = empty.
 */
class BoardReader private constructor(
    val rect: Rect,
    val flipped: Boolean,                 // true = black at the bottom
    private val tpl: List<Pair<Char, FloatArray>>,
    private val emptyStd: Float
) {
    class Feat(val v: FloatArray, val mean: Float, val std: Float)

    companion object {
        private const val N = 12          // samples per side per square
        private const val INSET = 0.18f   // skip square edges (coordinate labels, borders)

        private val START = arrayOf(
            "RNBQKBNR", "PPPPPPPP", "........", "........",
            "........", "........", "pppppppp", "rnbqkbnr"
        )
        val START_KEY = START.joinToString("/")

        fun toBoard(col: Int, row: Int, flipped: Boolean): Pair<Int, Int> =
            if (flipped) (7 - col) to row else col to (7 - row)

        fun feat(bmp: Bitmap, r: Rect, col: Int, row: Int): Feat {
            val s = r.width() / 8f
            val span = 1f - 2 * INSET
            val v = FloatArray(N * N)
            var sum = 0f
            for (j in 0 until N) for (i in 0 until N) {
                val x = (r.left + (col + INSET + span * (i + 0.5f) / N) * s).toInt().coerceIn(0, bmp.width - 1)
                val y = (r.top + (row + INSET + span * (j + 0.5f) / N) * s).toInt().coerceIn(0, bmp.height - 1)
                val p = bmp.getPixel(x, y)
                val l = 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)
                v[j * N + i] = l; sum += l
            }
            val mean = sum / v.size
            var sq = 0f
            for (k in v.indices) { v[k] -= mean; sq += v[k] * v[k] }
            val std = sqrt(sq / v.size)
            if (std > 1e-3f) for (k in v.indices) v[k] /= std   // normalize: survives move highlights
            return Feat(v, mean, std)
        }

        /** Board must be showing the starting position. */
        fun calibrate(bmp: Bitmap, r: Rect): BoardReader? {
            if (r.width() < 80) return null
            // Bottom and top rows have identical square-color mix, so the brightness gap is the pieces.
            var bottom = 0f; var top = 0f
            for (c in 0..7) { bottom += feat(bmp, r, c, 7).mean; top += feat(bmp, r, c, 0).mean }
            val flipped = bottom < top

            val tpl = ArrayList<Pair<Char, FloatArray>>()
            val empties = ArrayList<Float>(); val pieces = ArrayList<Float>()
            for (row in 0..7) for (col in 0..7) {
                val (f, rk) = toBoard(col, row, flipped)
                val ch = START[rk][f]
                val ft = feat(bmp, r, col, row)
                if (ch == '.') empties += ft.std else { pieces += ft.std; tpl += ch to ft.v }
            }
            val eMax = empties.max(); val pMin = pieces.min()
            val th = if (pMin > eMax) (eMax + pMin) / 2f else eMax * 1.5f
            return BoardReader(Rect(r), flipped, tpl, th)
        }
    }

    fun read(bmp: Bitmap): Array<CharArray> {
        val g = Array(8) { CharArray(8) { '.' } }
        for (row in 0..7) for (col in 0..7) {
            val ft = feat(bmp, rect, col, row)
            if (ft.std < emptyStd) continue
            var best = '.'; var bd = Float.MAX_VALUE
            for ((ch, t) in tpl) {
                var d = 0f
                for (k in t.indices) { val e = t[k] - ft.v[k]; d += e * e }
                if (d < bd) { bd = d; best = ch }
            }
            val (f, rk) = toBoard(col, row, flipped)
            g[rk][f] = best
        }
        return g
    }
}

object Fen {
    fun of(g: Array<CharArray>, side: Char): String {
        val rows = (7 downTo 0).map { r ->
            val sb = StringBuilder(); var run = 0
            for (f in 0..7) {
                val c = g[r][f]
                if (c == '.') { run++; continue }
                if (run > 0) { sb.append(run); run = 0 }
                sb.append(c)
            }
            if (run > 0) sb.append(run)
            sb.toString()
        }
        // Castling inferred from home squares; real rights aren't visible on screen.
        var cr = ""
        if (g[0][4] == 'K') { if (g[0][7] == 'R') cr += "K"; if (g[0][0] == 'R') cr += "Q" }
        if (g[7][4] == 'k') { if (g[7][7] == 'r') cr += "k"; if (g[7][0] == 'r') cr += "q" }
        return "${rows.joinToString("/")} $side ${cr.ifEmpty { "-" }} - 0 1"
    }

    fun sane(g: Array<CharArray>): Boolean {
        var wk = 0; var bk = 0
        for (r in 0..7) for (f in 0..7) {
            val c = g[r][f]
            if (c == 'K') wk++; if (c == 'k') bk++
            if ((r == 0 || r == 7) && (c == 'P' || c == 'p')) return false
        }
        return wk == 1 && bk == 1
    }
}
